package e2;

public interface Dependency {
    public void ejecutar(Graph g);
    public void eliminar();
}
