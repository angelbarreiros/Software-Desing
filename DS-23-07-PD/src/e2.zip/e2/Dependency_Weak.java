package e2;

public class Dependency_Weak implements Dependency {


    @Override
    public void ejecutar(Graph g) {

    }

    @Override
    public void eliminar() {

    }
}