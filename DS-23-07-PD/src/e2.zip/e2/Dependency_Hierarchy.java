package e2;

public class Dependency_Hierarchy implements Dependency{


    @Override
    public void ejecutar(Graph g) {

    }

    @Override
    public void eliminar() {

    }
}
