package e2;

public class Dpendency_Strong implements Dependency{

    @Override
    public void ejecutar(Graph g) {

    }

    @Override
    public void eliminar() {

    }
}
